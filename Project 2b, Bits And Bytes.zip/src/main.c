#include <bits_and_bytes.h>

int main() {
  print_it();
  print_int();
  print_float();
  print_char();
  packing_bytes();
  unpacking_bytes();
  print_bits();
  extracting_fields();
  updating_fields();
  return 0;
}
