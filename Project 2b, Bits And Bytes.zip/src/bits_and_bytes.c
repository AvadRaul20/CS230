#include <stdio.h>

void print_it() {
	printf("Bit operations are fun!\n");
}

void print_int(){
	int x = 10;
	int y = 13;
	printf("x = %d\n", x);
	printf("y = %d\n", y);
	int intType;
	printf("size of signed int in bytes is %ld.\n", sizeof(intType));
	printf("size of signed int in bits is %ld.\n",8*(sizeof(intType)));
	printf("%d + %d = %d.\n",x, y, x+y);
}

void print_float() {
  float x = 10;
  float y = 13;
  float floatType;
  printf("x = %f\n", x);
  printf("y = %f\n", y);
  printf("size of single float in bytes is %ld.\n", sizeof(floatType));
  printf("size of single float in bits is %ld.\n",8*sizeof(floatType));
  printf("%f + %f = %f.\n",x, y, x+y);
  int l = (int)(x+y);
  printf("%f + %f = %d.\n",x, y, l);
}

void print_char() {

  char c = 'C';
  char a = 65;
  char word[]  = "CAFEBABE";

  printf("c = %c\n", c);
  printf("a = %c\n", a);
  printf("%s\n", word);
  printf("number of bytes: %ld.\n", sizeof("CAFEBABE"));

}

void packing_bytes() {
  unsigned char b3 = 202;
  unsigned char b2 = 254;
  unsigned char b1 = 186;
  unsigned char b0 = 190;

  unsigned int u = 0;
  u = b3;
  u = (u << 8);
  u = u | b2;
  u = (u << 8);
  u = u | b1;
  u = (u << 8);
  u = u | b0;

  printf("%X\n", u);
}

void unpacking_bytes() {
  unsigned int i1 = 1835098984u;
  unsigned int i2 = 1768842611u;
  printf("%c", i1 >> 24);
  printf("%c", i1 >> 16);
  printf("%c", i1 >> 8);
  printf("%c", i1);
  printf("%c", i2 >> 24);
  printf("%c", i2 >> 16);
  printf("%c", i2 >> 8);
  printf("%c\n", i2);
}

void print_bits(){
  unsigned char a = 181;
  signed char b = -75;
  
  for(int i = 0; i < 8; i++){
    printf("%d", (((a << i) & (0x80))) ? 1 : 0);
  }
  printf("\n");
  
  for(int i = 0; i < 8; i++){
    printf("%d", (((b << i) & (0x80))) ? 1 : 0);
  }
  printf("\n");
  
}

void extracting_fields(){
  unsigned int extract = 0xCAFEBABE;
  unsigned int a,b,c,d,e,f,g,h,i,j;

  a = (extract >> 29);
  b = ((extract << 3) >> 28);
  c = ((extract  << 7) >> 28);
  d = ((extract  << 11) >> 29);
  e = ((extract  << 14) >> 29);
  f = ((extract  << 17) >> 28);
  g = ((extract  << 21) >> 28);
  h = ((extract  << 25) >> 29);
  i = ((extract  << 28) >> 30);
  j = ((extract  << 30) >> 30);

  printf("%d %d %d %d %d %d %d %d %d %d\n",a,b,c,d,e,f,g,h,i,j);

}

void updating_fields() {
  unsigned int val = 17512807u;
  val = val & 0xFFC3FFFF;
  val = val | (8 << 18);
  val = val & 0xFFFF83FF;
  val = val | (17 << 10);

  printf("%08X\n", val );
}	

