#include "bits.h"
#include "cache.h"
int get_set(Cache *cache, address_type address) {
  // TODO:
  //  Extract the set bits from a 32-bit address.
  //
  int set_bits = cache->set_bits;
  int block = cache->block_bits;
  int tag = 32 - block - set_bits;
  int sum = block + tag;
  address = (address << tag) >> sum;
  return address;
}

int get_line(Cache *cache, address_type address) {
  // TODO:
  // Extract the tag bits from a 32-bit address.
  //
  int block = cache->block_bits;
  int set = cache->set_bits;
  int sum = block + set;
  address = (address >> sum);
  return address;
}

int get_byte(Cache *cache, address_type address) {
  // TODO
  // Extract the block offset (byte index) bits from a 32-bit address.
  //
  int set = cache->set_bits;
  int block = cache->block_bits;
  int tag = 32 - set - block;
  int sum = tag + set;
  address = (address << sum) >>sum;
  return address;
}

