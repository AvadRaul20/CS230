#include <arpa/inet.h>
#include <ctype.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

#define MAXLINE 990 /* Max text line length */

int open_clientfd(char *hostname, int port) {
   // The client's socket file descriptor.
  int clientfd;

  // The hostent struct is used to get the IP address of the server
  // using DNS.
  //
  // struct hostent {
  //   char *h_name;        // official domain name of host
  //   char **h_aliases;    // null-terminated array of domain names
  //   int  h_addrtype;     // host address type (AF_INET)
  //   int  h_length;       // length of an address, in bytes
  //   char **h_addr_list;  // null-terminated array of in_addr structs
  // };
  struct hostent *hp;

  // serveraddr is used to record the server information (IP address
  // and port number).
  //
  // struct sockaddr_in {
  //   short            sin_family;   // e.g. AF_INET
  //   unsigned short   sin_port;     // e.g. htons(3490)
  //   struct in_addr   sin_addr;     // see struct in_addr, below
  //   char             sin_zero[8];  // zero this if you want to
  // };
  struct sockaddr_in serveraddr;

  // First, we create the socket file descriptor with the given
  // protocol and protocol family.
  if ((clientfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) return -1;

  // Query DNS for the host (server) information.
  if ((hp = gethostbyname(hostname)) == NULL) return -2;

  // The socket API requires that you zero out the bytes!
  bzero((char *)&serveraddr, sizeof(serveraddr));

  // Record the protocol family we are using to connect.
  serveraddr.sin_family = AF_INET;

  // Copy the IP address provided by DNS to our server address
  // structure.
  bcopy((char *)hp->h_addr_list[0], (char *)&serveraddr.sin_addr.s_addr,
        hp->h_length);

  // Convert the port from host byte order to network byte order and
  // store this in the server address structure.
  serveraddr.sin_port = htons(port);


  // Establish a connection with the server.
  if (connect(clientfd, (struct sockaddr *)&serveraddr, sizeof(serveraddr)) < 0)
    return -1;


  // Return the connected file descriptor.
  return clientfd;
}


char encryption(char shiftChar, int shift){
    char MAX = 'Z';
    char MIN = 'A';
    int i = 0;;
        if(shift == 0){
            return shiftChar;
        }
        else if(shiftChar + shift > MAX){
            int temp = (shiftChar + shift) - MAX;
            shiftChar = MIN + temp - 1;
        }
        else{
            shiftChar = shiftChar + shift;
        }
    return shiftChar;
}

int main(int argc, char **argv) {
  int clientfd;

  int port;
  // Variable to store the host/server domain name.
  char *host;

  // A buffer to receive data from the server.
  char buf[MAXLINE];

  // First, we check the program arguments:
  if (argc != 4) {
    exit(0);
  }

  host = argv[3];
  port = atoi(argv[2]);
  char *netid = argv[1];

  clientfd = open_clientfd(host, port);

  sprintf(buf, "cs230 HELLO %s\n",netid);
  send(clientfd, buf, strlen(buf), 0);

  int recv_len = recv(clientfd, buf, sizeof(buf), 0);
  buf[recv_len] = '\0';
  	 
  while(strstr(buf, "bye") != "bye"){
        char cs230[MAXLINE];
        int shift;
        char shiftVal[MAXLINE];
        char msg[MAXLINE];
        sscanf(buf, "%s %s %d %s", cs230, msg, &shift, shiftVal);
	int i = 0;
	while(i < strlen(shiftVal)){
        	shiftVal[i] = encryption(shiftVal[i], shift);
        	i++;
	}
	sprintf(cs230, "cs230 %s\n", shiftVal);
        send(clientfd, cs230, strlen(cs230), 0);
	
        int recv_len = recv(clientfd, buf, sizeof(buf), 0);
        buf[recv_len] = '\0';
  }
  close(clientfd);
  exit(0);
}

