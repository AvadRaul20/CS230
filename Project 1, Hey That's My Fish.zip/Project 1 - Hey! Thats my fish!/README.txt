This program uses pointers, malloc, structs, loops, and other in-built functions of C in order to complete the following functions:
create a contiguous blocks of memory with pointers in order to connect the grid, print the grid, take player input as well as validate it, 
proceed with updating the placement of the Player upon the grid, make an AI choose the best path for the highest score every turn, and 
count the points and provide the user with consistent updates of the situation in the game. "Hey! That's my fish" was created with 
multiple functions all being called within the main. The code uses loops consistently to move through the octagons with a temporary pointer
so that it can be checked for validity of the user input or the smartest movement for the AI. 