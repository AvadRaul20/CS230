/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Grid{
    char data;
    struct Grid *up;
    struct Grid *down;
    struct Grid *left;
    struct Grid *right;
    struct Grid *upLeft;
    struct Grid *upRight;
    struct Grid *downLeft;
    struct Grid *downRight;
    };

struct AIvalues{
    int AIintialPosition;
    int AIFinalPosition;
    int Score;
};


struct Grid* creategrid(struct Grid* grids, int PP, int AP){
    for(int i = 0; i < 36; i++){

        if((i < 6) || (i >= 30 && i < 36)){
            grids[i].data = '1';
        }
        
        if((i%6 == 0 && i > 0) || (i > 5 && i%6 == 5)){
            grids[i].data = '1';
        }
        
        if((i > 6 && i < 11) || (i > 24 && i < 29)){
            grids[i].data = '2';
        }
        
        if((i > 12 && i < 17) || (i > 18 && i < 23)){
            if(( i == 14 || i == 15) || ( i== 20 || i == 21)){
                grids[i].data = '3';
            }
            else{
                grids[i].data = '2';
            }
        }
        
        if(((i % 6 != 0) && (i % 6 != 5)) && ((i > 5) && (i < 30))){
            grids[i].upLeft = &grids[i - 7];
            grids[i].up = &grids[i - 6];
            grids[i].upRight = &grids[i - 5];
            grids[i].right = &grids[i + 1];
            grids[i].downRight = &grids[i + 7];
            grids[i].down = &grids[i + 6];
            grids[i].downLeft = &grids[i + 5];
            grids[i].left = &grids[i - 1];
        }
        
        if(i % 6 == 0){
            grids[i].left= NULL;
            grids[i].upLeft = NULL;
            grids[i].downLeft = NULL;
            grids[i].right = &grids[i + 1];

            
            if((i != 0) || (i != 30)){
                grids[i].up = &grids[i - 6];
                grids[i].down = &grids[i + 6];
                grids[i].upRight = &grids[i - 5];
                grids[i].downRight = &grids[i + 7];
            }
            
            if(i == 0){
                grids[i].up = NULL;
                grids[i].upRight = NULL;
                grids[i].downRight = &grids[i + 7];
                grids[i].down = &grids[i + 6];
            }
            
            if(i == 30){
                grids[i].up = &grids[i - 6];
                grids[i].upRight = &grids[i - 5];
                grids[i].downRight = NULL;
                grids[i].down = NULL;
            }
            
        }
        
        if(i % 6 == 5){
            grids[i].right = NULL;
            grids[i].upRight = NULL;
            grids[i].downRight = NULL;
            grids[i].left = &grids[i - 1];
            
            if((i != 5) || (i != 35)){
                grids[i].up = &grids[i - 6];
                grids[i].down = &grids[i + 6];
                grids[i].upLeft = &grids[i - 7];
                grids[i].downLeft = &grids[i + 5];
            }
            
            if(i == 5){
                grids[i].up = NULL;
                grids[i].upLeft = NULL;
                grids[i].downLeft = &grids[i + 5];
                grids[i].down = &grids[i + 6];
            }
            
            if(i == 35){
                grids[i].up = &grids[i - 6];
                grids[i].upLeft = &grids[i - 7];
                grids[i].downLeft = NULL;
                grids[i].down = NULL;
            }
        }
        
        if((i > 30) && (i < 35)){
            grids[i].up = &grids[i - 6];
            grids[i].down = NULL;
            grids[i].left = &grids[i - 1];
            grids[i].right = &grids[i + 1];
            grids[i].upLeft = &grids[i - 7];
            grids[i].upRight = &grids[i - 5];
            grids[i].downLeft = NULL;
            grids[i].downRight = NULL;
        }
        
        if((i > 0) && (i < 5)){
            grids[i].up = NULL;
            grids[i].down = &grids[i - 6];
            grids[i].left = &grids[i - 1];
            grids[i].right = &grids[i + 1];
            grids[i].upLeft = NULL;
            grids[i].upRight = NULL;
            grids[i].downLeft = &grids[i + 5];
            grids[i].downRight = &grids[i + 7];
        }
    }
    
    grids[PP].data = 'P';
    grids[AP].data = 'A';
    
    return grids;

}

//This function is to print grid as seen when the game is running. 
int printGrid(struct Grid *grids){
    printf(" 1 2 3 4 5 6 \n");
    
    for(int i = 0; i < 36; i++){
        
        printf(" %c", grids[i].data);
        
        int a = (i + 1)/6;
        if(i%6 == 5) printf(" %d", a);
        
        if(i % 6 == 5){
            printf("\n");
        }
        
    }
}

//The validate function checks if the user entered the correct input direction and distance to see if he is going
//off of the grid and to see if there is anything upon the path of the user to take him to his endpoint. 
int Validate(struct Grid *grids, char *userMove, int moveDistance, int PP){
 

    if(strcmp(userMove, "up") == 0  || strcmp(userMove, "upLeft") == 0 || strcmp(userMove,"left") == 0 || strcmp(userMove, "downLeft") == 0 || strcmp(userMove, "down") == 0 || strcmp(userMove, "downRight") == 0 || strcmp(userMove, "right") == 0 || strcmp(userMove, "upRight")  == 0){
    }
    else{
        printf("The direction you wrote was incorrect, please write it again correctly as shown above.\n");
        return 0;
    }

    if((moveDistance < 1) || (moveDistance > 5)){
        printf("But the distance you entered is too long! Please choose a distance within the grid.\n");
        return 0;
    }
    else{
    }
    
    int ctr = moveDistance;
    int flag = 0;
    struct Grid *gridData;
    
    if(strcmp(userMove, "down") == 0){
        while(ctr > 0){
            if(grids[PP].down == NULL || grids[PP].down->data == '.' || grids[PP].down->data == 'A'){
                flag = 1;
                break;
            }
            
            PP = PP + 6;
            
            ctr--;
        }
    }

    if(strcmp(userMove, "up") == 0){
        while(ctr > 0){
            if(grids[PP].up == NULL || grids[PP].up->data == '.' || grids[PP].up->data == 'A'){
                flag = 1;
                break;
            }
            
            PP = PP - 6;
            
            ctr--;
        }
    }
    
    if(strcmp(userMove, "left") == 0){
        while(ctr > 0){
            if(grids[PP].left == NULL || grids[PP].left->data == '.' || grids[PP].left->data == 'A'){
                flag = 1;
                break;
            }
            
            PP = PP - 1;
            
            ctr--;
        }
    }
    
    if(strcmp(userMove, "right") == 0){
        while(ctr > 0){
            if(grids[PP].right == NULL || grids[PP].right->data == '.' || grids[PP].right->data == 'A'){
                flag = 1;
                break;
            }
            
            PP = PP + 1;
            
            ctr--;
        }
    }
    
    if(strcmp(userMove, "upLeft") == 0){
        while(ctr > 0){
            if(grids[PP].upLeft == NULL || grids[PP].upLeft->data == '.' || grids[PP].upLeft->data == 'A'){
                flag = 1;
                break;
            }
            
            PP = PP - 5;
            
            ctr--;
        }
    }
    
    if(strcmp(userMove, "upRight") == 0){
        while(ctr > 0){
            if(grids[PP].upRight == NULL || grids[PP].upRight->data == '.' || grids[PP].upRight->data == 'A'){
                flag = 1;
                break;
            }
            
            PP = PP - 7;
            
            ctr--;
        }
    }
    
    if(strcmp(userMove, "downRight") == 0){
        while(ctr > 0){
            if(grids[PP].downRight == NULL || grids[PP].downRight->data == '.' || grids[PP].downRight->data == 'A'){
                flag = 1;
                break;
            }
            
            PP = PP + 7;
            
            ctr--;
        }
    }
    
    if(strcmp(userMove, "downLeft") == 0){
        while(ctr > 0){
            if(grids[PP].downLeft == NULL || grids[PP].downLeft->data == '.' || grids[PP].downLeft->data == 'A'){
                flag = 1;
                break;
            }
            
            PP = PP + 5;
            
            ctr--;
        }
    }


    if(flag == 1){
        printf("You're either moving out of the grid or are trying to access a point which is taken. Try again.\n");
        return 0;
    }
    else{
        return 1;
    }
}
//function to update the int PP (player position) in order to change the location of 'P' upon the grid. 
int updatePlayerPosition(int PP, struct Grid *grids, char *userMove, int userDistance){
    int IPP;
    IPP = PP;

    if(strcmp(userMove, "up")){
        PP = PP + userDistance*(6);
    }
    if(strcmp(userMove, "upRight")){
        PP = PP + userDistance*(5);
    }
    if(strcmp(userMove, "right")){
        PP = PP - userDistance;
    }
    if(strcmp(userMove, "downRight")){
        PP = PP - userDistance*7;
    }
    if(strcmp(userMove, "down")){
        PP = PP - userDistance*6;
    }
    if(strcmp(userMove, "downLeft")){
        PP = PP - userDistance*5;
    }
    if(strcmp(userMove, "left")){
        PP = PP + userDistance;
    }
    if(strcmp(userMove, "upLeft")){
        PP = PP + userDistance*(7);
    }
    

    return PP;

}


//This function checks if there is movement allowed by both players and to see if the game is over. 
int gameOver(struct Grid *grids, int PP, int AP){
    if((grids[PP].up == NULL || grids[PP].up->data == 'A' || grids[PP].up->data == '.') && (grids[PP].upRight == NULL || grids[PP].upRight->data == 'A' || grids[PP].upRight->data == '.') && (grids[PP].left == NULL || grids[PP].left->data == 'A' || grids[PP].left->data == '.') && (grids[PP].downLeft == NULL || grids[PP].downLeft->data == 'A' || grids[PP].downLeft->data == '.') && (grids[PP].down == NULL || grids[PP].down->data == 'A' || grids[PP].down->data == '.') && (grids[PP].downRight == NULL || grids[PP].downRight->data == 'A' || grids[PP].downRight->data == '.') && (grids[PP].upLeft == NULL || grids[PP].upLeft->data == 'A' || grids[PP].upLeft->data == '.')){
        printf("Thank You for Playing the game. You Lost!\n");
        return 1;
    }
    if((grids[AP].up == NULL || grids[AP].up->data == 'P' || grids[AP].up->data == '.') && (grids[AP].upRight == NULL || grids[AP].upRight->data == 'P' || grids[AP].upRight->data == '.') && (grids[AP].left == NULL || grids[AP].left->data == 'P' || grids[PP].left->data == '.') && (grids[AP].downLeft == NULL || grids[AP].downLeft->data == 'P' || grids[AP].downLeft->data == '.') && (grids[AP].down == NULL || grids[AP].down->data == 'P' || grids[AP].down->data == '.') && (grids[AP].downRight == NULL || grids[AP].downRight->data == 'P' || grids[AP].downRight->data == '.') && (grids[AP].upLeft == NULL || grids[AP].upLeft->data == 'P' || grids[AP].upLeft->data == '.')){
        printf("Thank You for Playing. You beat the computer! Yay!!!\n");
        return 1;
    }
    
    return 0;
    
}

void showScore(int playerScore, int computerScore){
    printf("User Score: %d\n", playerScore);
    printf("AI Score: %d\n", computerScore);
}
//This function returns the struct created for storing initial and final positions of the AI and keep up the score 
//It utilizes the values in the struct in order to update and see the path with the maximum score. 
struct AIvalues* AIMove(struct AIvalues *AIpositioning, struct Grid *grids, int computerScore, int AP){
    int AIstart = AIpositioning->AIintialPosition;
    int tempPos = AIpositioning->AIintialPosition;
    int maxScore = 0;
    int maxPos = -1;


    while(grids[tempPos].up != NULL && grids[tempPos].up->data != 'P' && grids[tempPos].up->data != '.'){
        if(grids[tempPos].up != NULL && grids[tempPos].up->data != 'P' && grids[tempPos].up->data != '.'){
            int tempScore = grids[tempPos].up->data - '0';
            if(tempScore > maxScore){
                maxPos = tempPos - 6;
                maxScore = tempScore;
            }
            tempPos = tempPos - 6;
        }
        else{
            continue;
        }
    }
    
    tempPos = AIpositioning->AIintialPosition;
    
    while(grids[tempPos].upRight != NULL && grids[tempPos].upRight->data != 'P' && grids[tempPos].upRight->data != '.'){
        if(grids[tempPos].upRight != NULL && grids[tempPos].upRight->data != 'P' && grids[tempPos].upRight->data != '.'){
            int tempScore = grids[tempPos].upRight->data - '0';
            if(tempScore > maxScore){
                maxPos = tempPos - 5;
                maxScore = tempScore;
            }
            tempPos = tempPos - 5;
        }
        else{
            continue;
        }
    }


    while(grids[tempPos].right != NULL && grids[tempPos].right->data != 'P' && grids[tempPos].right->data != '.'){
        if(grids[tempPos].right != NULL && grids[tempPos].right->data != 'P' && grids[tempPos].right->data != '.'){
            int tempScore = grids[tempPos].right->data - '0';
            if(tempScore > maxScore){
                maxPos = tempPos + 1;
                maxScore = tempScore;
            }
            tempPos = tempPos + 1;
        }
        else{
            continue;
        }
    }


    while(grids[tempPos].downRight != NULL && grids[tempPos].downRight->data != 'P' && grids[tempPos].downRight->data != '.'){
        if(grids[tempPos].downRight != NULL && grids[tempPos].downRight->data != 'P' && grids[tempPos].downRight->data != '.'){
            int tempScore = grids[tempPos].downRight->data - '0';
            if(tempScore > maxScore){
                maxPos = tempPos + 7;
                maxScore = tempScore;
            }
            tempPos = tempPos + 7;
        }
        else{
            continue;
        }
    }


    while(grids[tempPos].down!= NULL && grids[tempPos].down->data != 'P' && grids[tempPos].down->data != '.'){
        if(grids[tempPos].down!= NULL && grids[tempPos].down->data != 'P' && grids[tempPos].down->data != '.'){
            int tempScore = grids[tempPos].down->data - '0';
            if(tempScore > maxScore){
                maxPos = tempPos + 6;
                maxScore = tempScore;
            }
            tempPos = tempPos + 6;
        } 
        else{
            continue;
        }
    }


    while(grids[tempPos].downLeft != NULL && grids[tempPos].downLeft->data != 'P' && grids[tempPos].downLeft->data != '.'){
        if(grids[tempPos].downLeft != NULL && grids[tempPos].downLeft->data != 'P' && grids[tempPos].downLeft->data != '.'){
            int tempScore = grids[tempPos].downLeft->data - '0';
            if(tempScore > maxScore){
                maxPos = tempPos + 5;
                maxScore = tempScore;
            }
            tempPos = tempPos + 5;
        }
        else{
            continue;
        }
    }                    
    
    while(grids[tempPos].left != NULL && grids[tempPos].left->data != 'P' && grids[tempPos].left->data != '.'){
        if(grids[tempPos].left != NULL && grids[tempPos].left->data != 'P' && grids[tempPos].left->data != '.'){
            int tempScore = grids[tempPos].left->data - '0';
            if(tempScore > maxScore){
                maxPos = tempPos - 1;
                maxScore = tempScore;
            }
            tempPos = tempPos - 1;
        }  
        else{
            continue;
        }
    }

                        
    while(grids[tempPos].upLeft != NULL && grids[tempPos].upLeft->data != 'P' && grids[tempPos].upLeft->data != '.'){
        if(grids[tempPos].upLeft != NULL && grids[tempPos].upLeft->data != 'P' && grids[tempPos].upLeft->data != '.'){
            int tempScore = grids[tempPos].upLeft->data - '0';
            if(tempScore > maxScore){
                maxPos = tempPos - 7;
                maxScore = tempScore;
            }
            tempPos = tempPos - 7;
        } 
        else{
            continue;
        }
    }
    
    AIpositioning->AIFinalPosition = maxPos;
    AIpositioning->AIintialPosition = AP;
    AIpositioning->Score = maxScore;
     
    return AIpositioning;
   
}

//The main function utilizes all the functions which were mentioned above in order to process and play the game. 
int main(){
    
    int PP = 11;
    int IPP = PP;
    int AP = 30;
    int playerScore = 0;
    int computerScore = 0;
    
    struct Grid *grids =(struct Grid*)(malloc(36 * sizeof(struct Grid)));
    struct AIvalues *AIpositioning =(struct AIvalues*)(malloc(sizeof(struct AIvalues)));
    
    AIpositioning->Score = computerScore;
    AIpositioning->AIintialPosition = AP;
    grids = creategrid(grids, PP, AP);
    
    printGrid(grids);
    

    printf("\nHi there! Welcome to \"Hey! Thats my fish!\"\n");
    
    printf("\n");
    
    
    char *userMove;

    int userDistance;

    int endGame = 4;
    
    while(endGame != 0){
        
        printf("Please select one of the following moves: up, down, left, right, upLeft, upRight, downLeft, downRight... along with distance(number).\n");
        
        scanf("%ms %d", &userMove, &userDistance);
        
        while(Validate(grids, userMove, userDistance, PP) == 0){
            if(Validate(grids, userMove, userDistance, PP) == 0){
    
                scanf("%ms %d", &userMove, &userDistance);
                printGrid(grids);
            }
            else{
                continue;
            }
        }
        
        IPP = PP;
        PP = updatePlayerPosition(PP, grids, userMove, userDistance);
        
        playerScore += grids[PP].data - '0';
        
        grids[PP].data = 'P';
        grids[IPP].data = '.';
        

        if(gameOver(grids, PP, AP)){
            endGame = 0;
            printf("Final Scores:\n");
        }

        AIpositioning = AIMove(AIpositioning, grids, computerScore, AP);


        grids[AIpositioning->AIintialPosition].data = '.';
        
        AIpositioning->AIintialPosition = AIpositioning->AIFinalPosition;
        
        grids[AIpositioning->AIFinalPosition].data = 'A';
        
        AIpositioning->AIintialPosition = -1;
        
        AP = AIpositioning->AIFinalPosition;

        computerScore += AIpositioning->Score;

        printGrid(grids);
        
            
        showScore(playerScore, computerScore);
        

        
    }
//code to free up the memory allocations through malloc for the structs.
free(grids);
free(AIpositioning);
}
























